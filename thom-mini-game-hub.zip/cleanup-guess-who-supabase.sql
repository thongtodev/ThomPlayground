-- Thơm Playground 1.68.0
-- Remove ONLY the Supabase objects created for the retired game "Thơm Là Ai?".
-- Destructive for this game's rooms, secrets, actions and settings. Back up first if needed.
begin;

-- Remove the Realtime policy before its helper function.
drop policy if exists guess_who_receive on realtime.messages;

-- Remove public RPCs created by migrations 1.67.0–1.67.2.
drop function if exists public.guess_who_is_member(text);
drop function if exists public.guess_who_room(text, text, jsonb, integer, uuid);
drop function if exists public.guess_who_admin(jsonb, integer);

-- This schema was created exclusively for Thơm Là Ai?.
-- CASCADE removes its settings, matches, secrets, player-board states,
-- actions, pack backups, sequences and private helper functions.
drop schema if exists guess_who_private cascade;

-- Remove the retired game's availability flag while preserving every other game setting.
update public.game_settings
set value = coalesce(value, '{}'::jsonb) - 'guess-who'
where key = 'gameAvailability'
  and jsonb_typeof(value) = 'object'
  and value ? 'guess-who';

commit;

-- Verification: these checks should return no rows / a value without guess-who.
select n.nspname as remaining_private_schema
from pg_namespace n
where n.nspname = 'guess_who_private';

select p.proname as remaining_public_rpc
from pg_proc p
join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public'
  and p.proname in ('guess_who_is_member', 'guess_who_room', 'guess_who_admin');

select pol.polname as remaining_realtime_policy
from pg_policy pol
join pg_class c on c.oid = pol.polrelid
join pg_namespace n on n.oid = c.relnamespace
where n.nspname = 'realtime'
  and c.relname = 'messages'
  and pol.polname = 'guess_who_receive';

select key, value
from public.game_settings
where key = 'gameAvailability';
