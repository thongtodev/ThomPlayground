# Thơm Playground 1.70.0 – Hiệu ứng và crop Thơm Kim Cương

## Cập nhật

- Thêm trình phát animation theo timeline xác nhận bởi engine: swap, match, clear, gravity/drop, special, settle; khóa input cho đến khi hoàn tất chuỗi, chỉ hiện kết quả sau cascade.
- Hiệu ứng ghép, rơi, nổ vùng đặc biệt, combo, phản hồi vật cản, booster, sao và thông báo bằng ngôn ngữ chim cá; hỗ trợ giảm chuyển động, bật/tắt âm thanh và hiệu ứng.
- Admin crop trực tiếp bằng canvas 1:1, kéo/zoom/căn/xoay; **khi mở lại một ảnh, hiển thị đúng crop đã lưu**. Ảnh thu nhỏ trong danh sách cũng sử dụng crop đã lưu.
- Game và Admin dùng chung thuật toán render crop để đảm bảo xem trước giống ảnh xuất hiện trên ô 7×7. 24 ảnh gốc được giữ nguyên byte; chỉ lưu metadata vào `thomDiamondCrops` của cấu hình website.
- Bốn nhóm ảnh trong Admin có thể thu gọn; chưa crop luôn hiển thị toàn bộ ảnh theo contain.

## Kiểm thử

- 100 level: thử ít nhất một nước đi hợp lệ mỗi level, không phát sinh lỗi và có chuỗi sự kiện kết thúc bằng settle.
- Test dữ liệu game và test hồi quy crop/animation: đạt.
- Test toàn bộ repository: 241/247 đạt; 6 suite yêu cầu các package chưa cài được trong môi trường kiểm thử (PGlite / dependency liên quan). Cần chạy `npm ci`, `npm run build`, `npm test` trên máy có kết nối registry trước khi phát hành.
- Chưa kiểm thử trực tiếp trên thiết bị di động hoặc deploy lên production.

## Lưu ý

- Animation dựa trên snapshots engine, không thay đổi luật, số lượt, điểm hay cấu hình 100 level.
- Phiên bản này lưu crop trong game settings như phiên bản trước; không yêu cầu migration Supabase mới.
